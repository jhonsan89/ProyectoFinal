<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Aplicativo Sistema de Pacientes</title>
  <?php include("incluidos/css.php");?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php include("incluidos/header.php");?>
<h2>Bienvenido</h2>

</body>
</html>