<div class="container-fluid">
	<div class="container">
		<h2>enfermedades</h2>
		<hr>
<?php echo $tabla;?>

	</div>
	
</div>