<div class="container-fluid">
	<div class="container">
		<h2>Tipo de Sangre</h2>
		<hr>
		<?php echo $tabla;?>
	</div>
	
</div>